//
//  ViewController.swift
//  ProtocolTest
//
//  Created by NoodleKim on 2017. 4. 29..
//  Copyright © 2017년 NoodleKim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var items: [ListCellData] = [
        ListCellData(title: "title1", subTitle: "description1"),
        ListCellData(title: "title2", subTitle: "description2"),
        ListCellData(title: "title3", subTitle: "description3"),
        ListCellData(title: "title4", subTitle: "description4"),
        ListCellData(title: "title5", subTitle: "description5")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    // MARK: - UITableViewDelegate, DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = ListCell.init(style: UITableViewCellStyle.subtitle, reuseIdentifier: "listCell")
        let item = self.items[indexPath.row]
        cell.setCellData(cellData: item, index: indexPath) { 
            print("listCell selected!!")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.performSegue(withIdentifier: "showDetail", sender: nil)
    }

}

