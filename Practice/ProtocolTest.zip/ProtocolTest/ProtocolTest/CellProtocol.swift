//
//  CellProtocol.swift
//  ProtocolTest
//
//  Created by NoodleKim on 2017. 4. 29..
//  Copyright © 2017년 NoodleKim. All rights reserved.
//

import Foundation
import UIKit

protocol CellProtocol {
    associatedtype DataType
    
    var handler: (() -> Void)? { get set }

    var cellData: DataType? { get set }
    var index: IndexPath? { get set }
    func setCellData(cellData: DataType, index: IndexPath, handle: (() -> Void)?)
}
