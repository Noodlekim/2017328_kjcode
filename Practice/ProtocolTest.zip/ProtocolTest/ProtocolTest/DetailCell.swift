//
//  DetailCell.swift
//  ProtocolTest
//
//  Created by NoodleKim on 2017. 4. 29..
//  Copyright © 2017년 NoodleKim. All rights reserved.
//

import UIKit

struct DetailCellData {
    var title: String
    var subTitle: String
}

class DetailCell: UITableViewCell, CellProtocol {

    typealias DataType = DetailCellData
    
    var handler: (() -> Void)?

    var cellData: DataType?
    var index: IndexPath?
    func setCellData(cellData: DataType, index: IndexPath, handle: (() -> Void)?) {
        self.handler = handle
        self.cellData = cellData
        self.textLabel?.text = cellData.title
        self.detailTextLabel?.text = cellData.subTitle
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        if selected, let handle = self.handler {
            handle()
        }
    }
}
