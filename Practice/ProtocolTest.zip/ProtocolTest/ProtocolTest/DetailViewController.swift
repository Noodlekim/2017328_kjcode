//
//  DetailViewController.swift
//  ProtocolTest
//
//  Created by NoodleKim on 2017. 4. 29..
//  Copyright © 2017년 NoodleKim. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var items: [DetailCellData] = [
        DetailCellData(title: "detailTitle1", subTitle: "description1"),
        DetailCellData(title: "detailTitle2", subTitle: "description2"),
        DetailCellData(title: "detailTitle3", subTitle: "description3"),
        DetailCellData(title: "detailTitle4", subTitle: "description4"),
        DetailCellData(title: "detailTitle5", subTitle: "description5")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    // MARK: - UITableViewDelegate, DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = DetailCell.init(style: UITableViewCellStyle.subtitle, reuseIdentifier: "DetailCell")
        let item = self.items[indexPath.row]
        cell.setCellData(cellData: item, index: indexPath) { 
            print("DetailCell selected!!")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}

